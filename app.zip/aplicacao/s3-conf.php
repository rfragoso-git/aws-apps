<?php
$accessKey = 'AKIA4Z6Y6UKWNEFGMEMC';
$secretKey = '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';
$region = 'us-east-1';
$bucket = 'week-cloud';
$arqName =  'logo.jpg';
$linkestatico = 'http://week-cloud.s3-website-us-east-1.amazonaws.com/'
?>

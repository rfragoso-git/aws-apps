*<?php $RDS_URL='bd-scn.c3dlfe3v0b8w.us-east-1.rds.amazonaws.com'; $RDS_DB='dados'; $RDS_user='admin'; $RDS_pwd='nnf9604*';?>

